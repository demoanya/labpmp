package com.anna.demeshko.millionaire

/**
 * Created by mikemakhovyk on 06.04.2020.
 */
object Constants {
    const val QUESTION_COUNT = "question_count"
    const val IS_HINT_ENABLED = "is_hint_enabled"
}