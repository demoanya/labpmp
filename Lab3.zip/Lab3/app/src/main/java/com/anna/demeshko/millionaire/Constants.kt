package com.anna.demeshko.millionaire


object Constants {
    const val QUESTION_COUNT = "question_count"
    const val IS_HINT_ENABLED = "is_hint_enabled"
}